package com.example.mt_assignment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class activity_7 extends AppCompatActivity {

    private TextView textViewTitle, textViewResult;
    private ImageView imageViewResult;
    private Button buttonEdit, buttonDelete, buttonCancel;
    private String dataId, title, result, imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_7);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textViewTitle = findViewById(R.id.textViewTitle7);
        textViewResult = findViewById(R.id.textViewResult7);
        imageViewResult = findViewById(R.id.imageViewResult7);
        buttonEdit = findViewById(R.id.buttonEdit7);
        buttonDelete = findViewById(R.id.buttonDelete7);
        buttonCancel = findViewById(R.id.buttonCancel7);

        dataId = getIntent().getStringExtra("dataId");
        title = getIntent().getStringExtra("title");
        result = getIntent().getStringExtra("result");
        imageUri = getIntent().getStringExtra("imageUri");

        textViewTitle.setText(title);
        textViewResult.setText(result);
        if (imageUri != null && !imageUri.isEmpty()) {
            imageViewResult.setImageURI(Uri.parse(imageUri));
        }

        buttonEdit.setOnClickListener(v -> {
            Intent intent = new Intent(activity_7.this, activity_5.class);
            intent.putExtra("dataId", dataId);
            intent.putExtra("title", title);
            intent.putExtra("result", result);
            intent.putExtra("imageUri", imageUri);
            startActivity(intent);
        });

        buttonDelete.setOnClickListener(v -> deleteRecord());

        buttonCancel.setOnClickListener(v -> {
            Intent intent = new Intent(activity_7.this, activity_6.class);
            startActivity(intent);
            finish();
        });
    }

    private void deleteRecord() {
        if (dataId != null) {
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("AnalysedImages");
            myRef.child(dataId).removeValue().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Toast.makeText(activity_7.this, "Record deleted", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(activity_7.this, activity_6.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(activity_7.this, "Delete failed", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}