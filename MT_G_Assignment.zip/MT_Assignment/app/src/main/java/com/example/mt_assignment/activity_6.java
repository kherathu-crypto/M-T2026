package com.example.mt_assignment;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class activity_6 extends AppCompatActivity {

    private ListView listView;
    private Button buttonAdd;
    private List<AnalysedItem> itemList;
    private CustomAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_6);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listView = findViewById(R.id.listViewAnalysed);
        buttonAdd = findViewById(R.id.buttonAdd);
        itemList = new ArrayList<>();
        adapter = new CustomAdapter(this, itemList);
        listView.setAdapter(adapter);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("AnalysedImages");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                itemList.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    String id = dataSnapshot.getKey();
                    String title = dataSnapshot.child("title").getValue(String.class);
                    String result = dataSnapshot.child("result").getValue(String.class);
                    String imageUri = dataSnapshot.child("imageUri").getValue(String.class);
                    itemList.add(new AnalysedItem(id, title, result, imageUri));
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            AnalysedItem item = itemList.get(position);
            Intent intent = new Intent(activity_6.this, activity_7.class);
            intent.putExtra("dataId", item.id);
            intent.putExtra("title", item.title);
            intent.putExtra("result", item.result);
            intent.putExtra("imageUri", item.imageUri);
            startActivity(intent);
        });

        buttonAdd.setOnClickListener(v -> {
            Intent intent = new Intent(activity_6.this, Activity_1.class);
            startActivity(intent);
        });
    }

    private static class AnalysedItem {
        String id, title, result, imageUri;
        AnalysedItem(String id, String title, String result, String imageUri) {
            this.id = id; this.title = title; this.result = result; this.imageUri = imageUri;
        }
    }

    private static class CustomAdapter extends ArrayAdapter<AnalysedItem> {
        private final Context context;
        private final List<AnalysedItem> items;

        public CustomAdapter(Context context, List<AnalysedItem> items) {
            super(context, R.layout.list_item, items);
            this.context = context;
            this.items = items;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
            }
            AnalysedItem currentItem = items.get(position);
            ImageView img = convertView.findViewById(R.id.itemImage);
            TextView txt = convertView.findViewById(R.id.itemTitle);
            txt.setText(currentItem.title);
            if (currentItem.imageUri != null && !currentItem.imageUri.isEmpty()) {
                img.setImageURI(Uri.parse(currentItem.imageUri));
            } else {
                img.setImageResource(R.drawable.barcode);
            }
            if (position % 2 == 0) convertView.setBackgroundColor(Color.parseColor("#E0E0E0"));
            else convertView.setBackgroundColor(Color.WHITE);
            return convertView;
        }
    }
}