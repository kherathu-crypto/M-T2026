package com.example.mt_assignment;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;
import java.util.List;

public class activity_2 extends AppCompatActivity {

    private static final int REQUEST_PERMISSION = 3000;
    private String readerType;
    private Uri imageFileUri;
    private ImageView imageView;
    private TextView textViewOutput;
    private TextView textViewTitle;
    private TextView textViewInstructions;
    private View scrollViewResults;
    private Button editButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        readerType = getIntent().getStringExtra("reader");
        imageView = findViewById(R.id.imageView3);
        textViewOutput = findViewById(R.id.textViewMLKit);
        textViewTitle = findViewById(R.id.textView5);
        textViewInstructions = findViewById(R.id.textView6);
        scrollViewResults = findViewById(R.id.scrollViewMLKit);
        editButton = findViewById(R.id.button4);

        if ("barcode".equals(readerType)) {
            imageView.setImageResource(R.drawable.barcode);
        } else if ("content".equals(readerType)) {
            imageView.setImageResource(R.drawable.content);
        } else if ("text".equals(readerType)) {
            imageView.setImageResource(R.drawable.text);
        }

        editButton.setOnClickListener(v -> {
            Intent intent = new Intent(activity_2.this, activity_5.class);
            intent.putExtra("imageUri", imageFileUri != null ? imageFileUri.toString() : "");
            intent.putExtra("title", textViewTitle.getText().toString());
            intent.putExtra("result", textViewOutput.getText().toString());
            startActivity(intent);
        });
    }

    private void showResultsLayout(String dynamicTitle) {
        textViewInstructions.setVisibility(View.GONE);
        if (scrollViewResults != null) scrollViewResults.setVisibility(View.VISIBLE);
        textViewOutput.setVisibility(View.VISIBLE);
        editButton.setVisibility(View.VISIBLE);

        if (dynamicTitle != null && !dynamicTitle.isEmpty()) {
            textViewTitle.setText(dynamicTitle);
        } else {
            if ("barcode".equals(readerType)) textViewTitle.setText("Barcode Reader");
            else if ("content".equals(readerType)) textViewTitle.setText("Content Reader");
            else if ("text".equals(readerType)) textViewTitle.setText("Text Reader");
        }
    }

    public void openCamera(View view) {
        if (!checkPermission()) return;
        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        imageFileUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new ContentValues());
        takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri);
        activityResultLauncher.launch(takePhotoIntent);
    }

    public void loadImage(View view) {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        activityResultLauncher.launch(galleryIntent);
    }

    private boolean checkPermission() {
        String permission = Manifest.permission.CAMERA;
        boolean grantCamera = ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED;
        if (!grantCamera) {
            ActivityCompat.requestPermissions(this, new String[]{permission}, REQUEST_PERMISSION);
        }
        return grantCamera;
    }

    ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == RESULT_OK) {
                        if (result.getData() != null && result.getData().getData() != null) {
                            imageFileUri = result.getData().getData();
                        }
                        imageView.setImageURI(imageFileUri);
                        
                        textViewOutput.setText("");
                        InputImage image = null;
                        try {
                            image = InputImage.fromFilePath(getBaseContext(), imageFileUri);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        if (image != null) {
                            if ("barcode".equals(readerType)) processImageFromBarcodeReader(image);
                            else if ("content".equals(readerType)) processImageFromContentReader(image);
                            else if ("text".equals(readerType)) processImageFromTextReader(image);
                        }
                    }
                }
            });

    private void processImageFromBarcodeReader(InputImage image) {
        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).build();
        BarcodeScanner scanner = BarcodeScanning.getClient(options);
        scanner.process(image)
                .addOnSuccessListener(barcodes -> {
                    if (barcodes.isEmpty()) {
                        textViewOutput.append("Barcode not found.\n");
                    } else {
                        boolean isQr = false;
                        for (Barcode b : barcodes) {
                            if (b.getFormat() == Barcode.FORMAT_QR_CODE) {
                                isQr = true;
                                break;
                            }
                        }
                        String header = isQr ? "Detected QR code:" : "Detected barcode:";
                        textViewOutput.append(Html.fromHtml("<font color='navy'><b>" + header + "</b></font><br>", Html.FROM_HTML_MODE_LEGACY));
                        for (Barcode barcode : barcodes) {
                            textViewOutput.append(barcode.getRawValue() + "\n");
                        }
                    }
                    showResultsLayout("Barcode Reader");
                })
                .addOnFailureListener(e -> textViewOutput.setText("Failed"));
    }

    private void processImageFromContentReader(InputImage image) {
        ImageLabeler labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS);
        labeler.process(image)
                .addOnSuccessListener(labels -> {
                    if (labels.isEmpty()) {
                        showResultsLayout("Content Reader");
                        textViewOutput.append("Nothing found in the image\n");
                        return;
                    }
                    showResultsLayout("Content Reader");
                    textViewOutput.append(Html.fromHtml("<font color='navy'><b>Recognised image content:</b></font><br>", Html.FROM_HTML_MODE_LEGACY));
                    int counter = 1;
                    for (ImageLabel label : labels) {
                        textViewOutput.append(" " + counter + ". " + label.getText() + " (" + String.format("%.1f", label.getConfidence() * 100.0f) + "% confidence)\n");
                        counter++;
                    }
                })
                .addOnFailureListener(e -> textViewOutput.setText("Failed"));
    }

    private void processImageFromTextReader(InputImage image) {
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(image)
                .addOnSuccessListener(visionText -> {
                    String fullText = visionText.getText();
                    showResultsLayout("Text Reader");
                    textViewOutput.append(Html.fromHtml("<font color='navy'><b>Recognised text:</b></font><br>", Html.FROM_HTML_MODE_LEGACY));
                    if (fullText != null && fullText.length() > 1) textViewOutput.append(" " + fullText + "\n");
                    else textViewOutput.append(" No text found.\n");
                })
                .addOnFailureListener(e -> textViewOutput.setText("Failed"));
    }
}