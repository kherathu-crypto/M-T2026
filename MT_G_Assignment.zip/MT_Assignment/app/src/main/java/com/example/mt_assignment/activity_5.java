package com.example.mt_assignment;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class activity_5 extends AppCompatActivity {

    private EditText editTextTitle, editTextResult;
    private ImageView imageViewResult;
    private Button buttonSave;
    private Uri imageUri;
    private String dataId; 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_5);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editTextTitle = findViewById(R.id.editTextTitle);
        editTextResult = findViewById(R.id.editTextResult);
        imageViewResult = findViewById(R.id.imageViewResult);
        buttonSave = findViewById(R.id.buttonSave);

        String uriString = getIntent().getStringExtra("imageUri");
        String title = getIntent().getStringExtra("title");
        String result = getIntent().getStringExtra("result");
        dataId = getIntent().getStringExtra("dataId"); 

        if (uriString != null && !uriString.isEmpty()) {
            imageUri = Uri.parse(uriString);
            imageViewResult.setImageURI(imageUri);
        }
        editTextTitle.setText(title);
        editTextResult.setText(result);

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveData();
            }
        });
    }

    private void saveData() {
        String title = editTextTitle.getText().toString();
        String result = editTextResult.getText().toString();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("AnalysedImages");

        Map<String, Object> data = new HashMap<>();
        data.put("title", title);
        data.put("result", result);

        if (dataId == null || dataId.isEmpty()) {
            Uri savedImageUri = saveImageToInternalStorage();
            if (savedImageUri != null) {
                data.put("imageUri", savedImageUri.toString());
            }

            String id = myRef.push().getKey();
            if (id != null) {
                myRef.child(id).setValue(data).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(activity_5.this, "New record saved", Toast.LENGTH_SHORT).show();
                        navigateToActivity6();
                    }
                });
            }
        } else {
            myRef.child(dataId).updateChildren(data).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Toast.makeText(activity_5.this, "Record updated", Toast.LENGTH_SHORT).show();
                    navigateToActivity6();
                }
            });
        }
    }

    private void navigateToActivity6() {
        Intent intent = new Intent(activity_5.this, activity_6.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    private Uri saveImageToInternalStorage() {
        if (imageViewResult.getDrawable() == null) return null;
        Bitmap bitmap = ((BitmapDrawable) imageViewResult.getDrawable()).getBitmap();
        String fileName = "Analysed_" + System.currentTimeMillis() + ".jpg";
        try {
            java.io.File directory = new java.io.File(getFilesDir(), "AnalysedImages");
            if (!directory.exists()) directory.mkdirs();
            java.io.File file = new java.io.File(directory, fileName);
            java.io.FileOutputStream fos = new java.io.FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.close();
            return Uri.fromFile(file);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to save image", Toast.LENGTH_SHORT).show();
        }
        return null;
    }
}